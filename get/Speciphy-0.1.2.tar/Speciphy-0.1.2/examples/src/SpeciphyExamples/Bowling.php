<?php
namespace SpeciphyExamples;

class Bowling
{
    public $score = 0;

    public function hit($pins)
    {
    }
}
