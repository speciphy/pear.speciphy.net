<?php
namespace Speciphy;

interface ExampleInterface
{
    public function getDescription();
    public function getExampleGroup();
    public function isPending();
}
