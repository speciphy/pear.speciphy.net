<?php
namespace Speciphy\Tests;

/**
 * Basic TestCase class of Speciphy.
 *
 * @author Yuya Takeyama
 */
class TestCase extends \PHPUnit_Framework_TestCase
{
}
